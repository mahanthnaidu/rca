# ROOT CAUSE ANALYSIS README

## INTRODUCTION ##
Root Cause Analysis (RCA) is a systematic method used to identify the underlying reasons for anomalies or issues within a system. This project applies RCA techniques to analyze business metrics related to payment gateways and transaction modes, aiming to pinpoint the root causes of discrepancies in transaction success rates.

This project is implemented using two approaches:
1) One-Phase RCA Approach ( non causal graph approach )
2) Two-Phase RCA Approach ( requires a causal graph as input )

## One-Phase Approach:
The One-Phase RCA approach focuses on non-causal graph methods, primarily using statistical tests to identify the root causes of the anomalies and their significance.

# RCA Models:
Epsilon Diagnosis: This method assesses anomalies by comparing normal and anomalous values using statistical tests such as Kolmogorov-Smirnov Test (KS-test), T-Test (t-test), and Levene Test.

## Two-Phase RCA Approach:
The Two-Phase RCA approach involves causal graphs, aiming to establish causal relationships between metrics and then aiming to identify the root causes of the anomalies.

# Causal Graph:

GES (Greedy Equivalence Search): A score-based causal discovery algorithm used to learn the structure of causal graphs from observational data.

PC (Peter-Clark): A constraint-based causal discovery algorithm that infers causal relationships, considering conditional independence tests.

# RCA Models:

Random Walk: Algorithm for exploring causal relationships and identifying root causes based on random walks within the causal graph.

Hypothesis Testing: Method to identify significant causal relationships between metrics using regression techniques to pinpoint root causes.

## INSTALLATIONS ##

### pyrca
- Install pyrca: `pip install sfr-pyrca`
- For pyrca plotting & visualization: `pip install sfr-pyrca[plot]`
- Install all pyrca dependencies: `pip install sfr-pyrca[all]`

### causal-learn
- Install causal-learn: `pip install causal-learn`

### scipy
- Install scipy: `pip install scipy`

### pygraphviz
- Update apt-get: `sudo apt-get update`
- Install graphviz and graphviz-dev: `sudo apt-get install graphviz graphviz-dev`
- Install pygraphviz: `pip install pygraphviz`


## INSTRUCTIONS ##

1) Run the 'main.py' file using the command: python main.py.

2) Ensure all input files are located within the 'datasets' directory. The implementation directly references files such as 'final_dataset.csv', 'final_anomaly_names.csv', and 'background_knowledge.csv'.

  - final_dataset.csv: Contains the entire dataset, including both normal and abnormal data.

  - final_anomaly_names.csv: Lists anomalous date-hours and their corresponding root causes.

  - background_knowledge.csv: Provides background domain knowledge used for constructing the causal graph.

3) Select either option 1 or 2 based on your chosen approach.

4) If selecting option 1:

    - Choose the statistical test you wish to use to identify root causes.

5) If selecting option 2:

    - Choose the causal graph algorithm you want to employ.
    - Utilize a well-known domain knowledge graph for enhanced accuracy and reduced time complexity.
    - After causal graph generation, select your RCA model you want to use to identify the root causes.

6) Follow the format specified below for inputting background knowledge files.
. 

### Background Domain Knowledge
To facilitate causal graph generation, ensure you have prepared your background domain knowledge file in a CSV format named `background_knowledge.csv`. This file should be located within the `datasets` directory. Each line in `background_knowledge.csv` must adhere to one of the following formats:
- To specify a directed edge from `metric_A` to `metric_B`: `required,metric_A,metric_B`
- To exclude a directed edge from `metric_A` to `metric_B`: `forbidden,metric_A,metric_B`

Please ensure correct formatting to ensure proper functionality and readability of your domain knowledge specifications.
