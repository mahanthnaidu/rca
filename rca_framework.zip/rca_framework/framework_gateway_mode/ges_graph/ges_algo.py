import warnings
import pandas as pd
import networkx as nx
from causallearn.search.ScoreBased.GES import ges

warnings.filterwarnings('ignore')

def process_adjacency_matrix(adjacency_matrix, forbidden_edges, required_edges):
    """
    Processes the adjacency matrix by setting forbidden and required edges.

    The adjacency matrix is used to represent the directed edges in a causal graph.
    - adjacency_matrix[i, j] = 1 indicates a directed edge from node i to node j.
    - adjacency_matrix[i, j] = 0 indicates no edge between node i and node j.

    Parameters:
    - adjacency_matrix (np.ndarray): Initial adjacency matrix.
    - forbidden_edges (list of tuple): List of edges that are forbidden. Each tuple (i, j) indicates an edge from node i to node j is forbidden.
    - required_edges (list of tuple): List of edges that are required. Each tuple (i, j) indicates an edge from node i to node j is required.

    Returns:
    - np.ndarray: Processed adjacency matrix with the forbidden and required edges applied.
    """
    n = adjacency_matrix.shape[0]
    for i in range(n - 1):
        for j in range(i + 1, n):
            if adjacency_matrix[i, j] == -1 and adjacency_matrix[j, i] == -1:
                adjacency_matrix[j, i] = 0
                adjacency_matrix[i, j] = 0
            elif adjacency_matrix[i, j] == -1 and adjacency_matrix[j, i] == 0:
                adjacency_matrix[j, i] = 1
            elif adjacency_matrix[i, j] == 0 and adjacency_matrix[j, i] == -1:
                adjacency_matrix[i, j] = 1
    adjacency_matrix[adjacency_matrix == -1] = 0

    for (i, j) in forbidden_edges:
        adjacency_matrix[i, j] = 0
    for (i, j) in required_edges:
        adjacency_matrix[i, j] = 1
        adjacency_matrix[j, i] = 0

    return adjacency_matrix

def build_causal_graph(data, score_func='local_score_BIC', maxP=None, parameters=None):
    """
    Builds a causal graph using the GES algorithm.
    The nodes of the graph represent the column names, and the directed edges represent the causal relationships 
    between the nodes(metrics) indicated by the adjacency matrix.

    Parameters:
    - data (np.ndarray): Data for which the causal graph is to be built.
    - score_func (str): Score function to use. Default is 'local_score_BIC'.
      Choices for score_func are ['local_score_BIC', 'local_score_BDeu', 'local_score_cv_general', 
      'local_score_marginal_general', 'local_score_cv_multi', 'local_score_marginal_multi'].
    - maxP (int): Optional maximum number of parents for any node.
    - parameters (dict): Additional parameters for the GES algorithm.

    Returns:
    - np.ndarray: Adjacency matrix of the causal graph.
    """
    record = ges(data, score_func=score_func, maxP=maxP, parameters=parameters)
    adjacency_matrix = record['G'].graph
    return adjacency_matrix

def save_graph_as_png(adjacency_matrix, column_names, output_path='causal_graph.png'):
    """
    Saves the adjacency matrix as a PNG image of the causal graph.

    The adjacency matrix represents the directed edges in a causal graph.
    - adjacency_matrix[i, j] = 1 indicates a directed edge from node i to node j.
    - adjacency_matrix[i, j] = 0 indicates no edge between node i and node j.

    Parameters:
    - adjacency_matrix (np.ndarray): Adjacency matrix.
    - column_names (list): List of column names.
    - output_path (str): Path to save the PNG image.
    """
    G = nx.DiGraph()

    for var in column_names:
        G.add_node(var)

    for i, var1 in enumerate(column_names):
        for j, var2 in enumerate(column_names):
            if adjacency_matrix[i, j] == 1:
                G.add_edge(var1, var2)

    A = nx.nx_agraph.to_agraph(G)
    A.layout(prog='dot')

    A.draw(output_path)

def parse_background_knowledge(file_path, variable_names):
    """
    Parses the background knowledge file to extract the forbidden and required edges.

    Parameters:
    - file_path (str): Path to the background knowledge file.
    - variable_names (list): List of variable names representing the node names.

    Returns:
    - tuple: Lists of forbidden and required edges.
    """
    forbidden_edges = []
    required_edges = []
    with open(file_path, 'r') as file:
        for line in file:
            parts = line.strip().split(',')
            if parts[0].strip() == 'forbidden':
                forbidden_edges.append((variable_names.index(parts[1].strip()), variable_names.index(parts[2].strip())))
            elif parts[0].strip() == 'required':
                required_edges.append((variable_names.index(parts[1].strip()), variable_names.index(parts[2].strip())))
    return forbidden_edges, required_edges

def ges_causal_graph(normal_df, background_file):
    """
    Generates a causal graph using the GES algorithm and background domain knowledge.
    
    The causal graph is used for further root cause analysis. If there is a directed edge from node i to node j, 
    it implies that node i has a cause and effect relationship with node j. The adjacency matrix is processed 
    based on the forbidden and required edges specified in the domain knowledge file.

    Parameters:
    - normal_df (pd.DataFrame): DataFrame containing the normal data.
    - background_file (str): Path to the background knowledge file.

    Returns:
    - pd.DataFrame: DataFrame representing the adjacency matrix of the causal graph.
    """
    del_columns = [normal_df.columns[0], 'anomaly']
    normal_df = normal_df.drop(columns=del_columns)
    variable_names = list(normal_df.columns)
    # choices = ['local_score_BIC', 'local_score_BDeu', 'local_score_cv_general', 'local_score_marginal_general', 'local_score_cv_multi', 'local_score_marginal_multi']
    score_func = 'local_score_BIC'
    output_file = 'ges_causal_graph.png'

    forbidden_edges, required_edges = parse_background_knowledge(background_file, variable_names)
    
    data = normal_df.values

    adjacency_matrix = build_causal_graph(data, score_func=score_func)
    processed_matrix = process_adjacency_matrix(adjacency_matrix, forbidden_edges, required_edges)
    save_graph_as_png(processed_matrix, variable_names, output_path=output_file)

    graph_df = pd.DataFrame(processed_matrix, index=variable_names, columns=variable_names)

    return graph_df
