import csv
import warnings
import pandas as pd
from collections import defaultdict  
from ht_rca.ht_algo import ht_rca_func
from pc_graph.pc_algo import pc_causal_graph
from ges_graph.ges_algo import ges_causal_graph
from random_walk_rca.random_walk_algo import random_walk_func
from background_graph.causal_graph import domain_knowledge_graph
from epsilon_diagnosis.epsilon_diagnosis import epsilon_diagnosis_function

warnings.filterwarnings('ignore')

def calculate_accuracy(predicted_root_causes, actual_root_causes):
    """
    Calculates the accuracy of our model using the predicted root causes by comparing it to actual root causes.

    Args:
    - predicted_root_causes (dict): Dictionary of predicted root causes for each date-hour.
    - actual_root_causes (dict): Dictionary of actual root causes for each date-hour.

    Returns:
    - sorted_accuracy_results (dict): Dictionary sorted by accuracy, containing accuracy metrics for each date-hour.
    """
    accuracy_results = {}
    for dt_hr in actual_root_causes:
        if dt_hr in predicted_root_causes:
            actual_set = actual_root_causes[dt_hr]
            predicted_set = predicted_root_causes[dt_hr]
            
            correct_predictions = len(actual_set.intersection(predicted_set))
            total_actual = len(actual_set)
            
            accuracy = correct_predictions / total_actual if total_actual > 0 else 0
            accuracy_results[dt_hr] = (accuracy, correct_predictions, total_actual)
        else:
            accuracy_results[dt_hr] = (0, 0, 0)
    
    sorted_accuracy_results = dict(sorted(accuracy_results.items(), key=lambda item: (item[1][0], item[1][1]), reverse=True))
    total_ = 0
    common_ = 0 
    for dt_hr, (accuracy, common, total) in sorted_accuracy_results.items():
        total_ = total_ + total
        common_ = common_ + common
    print("****************************************************************************************")
    print(f"Final Model Accuracy: {(common_/total_):.2f}")
    print("****************************************************************************************")
    return sorted_accuracy_results

def process_csv(filename):
    """
    Process the CSV file to extract the date-hour along with their gateway-mode combinations of the anomalies.

    Args:
    - filename (str): Path to the input CSV file which contains the anamolies date-hour and gateway-mode combinations.

    Returns:
    - result (dict): Dictionary mapping each anomaly date-hour to a set of anomaly gateway-mode combinations.
    - max_len (int): Maximum number of root causes for any anomaly date-hour.
    """
    result = defaultdict(set)
    with open(filename, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        
        for row in reader:
            dt_hr = row['dt_hr']
            gateway = row['gateway'].replace('gateway_', '')
            modes = row['mode'].split(',')
            for mode in modes:
                mode = mode.replace('mode_', '')
                value = f"{gateway}_{mode}"
                result[dt_hr].add(value)
    
    max_len = max(len(val) for val in result.values())
    return dict(result), max_len

def add_anomaly_column(input_file, dev=0.3):
    """
    Adds an 'anomaly' column to the input dataset based on anomaly dates provided in 'datasets/final_anomaly_names.csv'.
    Anomalies are marked with 1 in the 'anomaly' column; otherwise, it is marked as 0. 
    The dataset is then divided into abnormal and normal datasets based on these anomalies.
    Additionally, calculates the absolute deviations for anomaly date-hours, which are crucial for 
    root cause analysis using methods like epsilon diagnosis.

    Args:
    - input_file (str): Path to the input CSV file containing the dataset to label with anomalies.
    - dev (float, optional): Deviation threshold percentage for anomaly detection (default is 0.3).

    Returns:
    - df (DataFrame): Original DataFrame with an added 'anomaly' column indicating anomalies.
    - normal_df (DataFrame): DataFrame containing rows classified as normal (not marked as anomalies).
    - abnormal_df (DataFrame): DataFrame containing rows classified as abnormal (marked as anomalies).
    - abs_dev_percentages (list): List of absolute deviation percentages for each abnormal row.
    """

    df = pd.read_csv(input_file)
    df['anomaly'] = 0
    normal_rows = []
    abnormal_rows = []
    abs_dev_percentages = []
    anomaly_df = pd.read_csv('datasets/final_anomaly_names.csv')
    anomaly_dates_ac = list(anomaly_df['dt_hr'].unique())
    
    for i in range(len(df)):
        current_row = df.iloc[i:i+1]
        if i >= 24:
            last_24_avg = df.iloc[i-24:i, 1].mean()
        else:
            last_24_avg = df.iloc[:i, 1].mean() if i > 0 else df.iloc[i, 1]
        
        if last_24_avg != 0:
            abs_dev_percent = (abs(current_row.iloc[0, 1] - last_24_avg) / last_24_avg) * 100
        
        if df['dt_hr'].iloc[i] in anomaly_dates_ac:
            df.at[i, 'anomaly'] = 1
            abs_dev_percentages.append(abs_dev_percent)
            abnormal_rows.append(current_row)
        else:
            normal_rows.append(current_row)
    
    normal_df = pd.concat(normal_rows, ignore_index=True)
    abnormal_df = pd.concat(abnormal_rows, ignore_index=True)
    
    normal_df.to_csv('datasets/normal_dataset.csv', index=False)
    abnormal_df.to_csv('datasets/abnormal_dataset.csv', index=False)
    df.to_csv(input_file[:-4] + '_with_anomaly_label.csv', index=False)
    
    return df, normal_df, abnormal_df, abs_dev_percentages

# def add_anomaly_column(input_file, dev=0.3):
#     """
#     Adds an 'anomaly' label to a time-series dataset based on deviation from the last 24-hour average.
#     If the deviation is greater then 30% then it is considered as anomaly otheriwse not.
#     Anomalies are marked with 1 in the 'anomaly' column; otherwise, it is marked as 0. 
#     The dataset is then divided into abnormal and normal datasets based on these anomalies.
#     Additionally, calculates the absolute deviations for anomaly date-hours, which are crucial for 
#     root cause analysis using methods like epsilon diagnosis.

#     Parameters:
#     - input_file (str): Path to the input CSV file containing timestamped data.
#     - dev (float, optional): Deviation threshold (percentage) for anomaly detection (default is 0.07, i.e., 7%).

#     Returns:
#     - df (DataFrame): Original DataFrame with added 'anomaly' column indicating anomalies.
#     - normal_df (DataFrame): DataFrame containing rows classified as normal (not marked as anomalies).
#     - abnormal_df (DataFrame): DataFrame containing rows classified as abnormal (marked as anomalies).
#     - abs_dev_percentages (list): List of absolute deviation percentages for each abnormal row.
#     """
#     df = pd.read_csv(input_file)
#     df['anomaly'] = 0
    
#     normal_df = df.iloc[:24].copy()
#     abnormal_df = pd.DataFrame(columns=df.columns)
#     abs_dev_percentages = []
    
#     for i in range(24, len(df)):
#         current_row = df.iloc[i:i+1]
#         last_24_avg = normal_df.iloc[-24:, 1].mean()  
#         abs_dev_percent = (abs(current_row.iloc[0, 1] - last_24_avg) / last_24_avg) * 100
#         abs_dev_percentages.append(abs_dev_percent)

#         if abs_dev_percent >= dev * 100:
#             df.at[i, 'anomaly'] = 1
#             abnormal_df = pd.concat([abnormal_df, current_row], ignore_index=True)
#         else:
#             normal_df = pd.concat([normal_df, current_row], ignore_index=True)
       
#     normal_df.to_csv('datasets/normal_dataset.csv', index=False)
#     abnormal_df.to_csv('datasets/abnormal_dataset.csv', index=False)
#     df.to_csv(input_file[:-4] + '_with_anomaly_label.csv', index=False)
    
#     return df, normal_df, abnormal_df, abs_dev_percentages

class RCAFramework:
    """
    Root Cause Analysis Framework for identifying root causes of anomalies.

    This framework supports both one-phase and two-phase RCA models:
    
    1. One-Phase RCA:
       - Epsilon Diagnosis Model.
    
    2. Two-Phase RCA:
       - First Phase: Causal graph generation using Domain Knowledge, GES (Greedy Equivalence Search), or PC (Peter and Clark Algorithm).
       - Second Phase: Root cause identification using Hypothesis Testing or Random Walk.

    Attributes:
    - dataset (str): Path to the dataset CSV file.
    - k (int): Number of top root causes to identify.
    - background_knowledge (str): Path to background knowledge CSV file.
    - result_dict (dict): Dictionary of actual root causes.
    """
    
    def __init__(self, dataset, k, background_knowledge, actual_dict):
        self.model_type = None
        self.algorithm_type1 = None
        self.algorithm_type2 = None
        self.dataset = dataset
        self.num_root_causes = k
        self.epsilon_diagnosis_type = None
        self.background_knowledge = background_knowledge
        self.actual_dict = actual_dict
        self.predicted_dict = None
    
    def select_model(self):
        """
        Allows the user to select the RCA model type (One-Phase or Two-Phase).
        """
        print("Select RCA Model:")
        print("1. One-Phase Model")
        print("2. Two-Phase Model")
        choice = int(input("Enter your choice (1 or 2): "))
        if choice == 1:
            self.model_type = 'One-Phase'
            self.select_one_phase_algorithm()
        elif choice == 2:
            self.model_type = 'Two-Phase'
            self.select_two_phase_algorithm()
        else:
            print("Invalid choice. Please select 1 or 2.")
            self.select_model()
    
    def select_one_phase_algorithm(self):
        """
        Allows the user to select the algorithm for One-Phase RCA.
        """
        print("Select Algorithm for One-Phase Model:")
        print("1. RCD (Root Causal Discovery)")
        print("2. Epsilon Diagnosis")
        choice = int(input("Enter your choice (1 or 2): "))
        if choice == 1:
            self.algorithm_type1 = 'RCD'
        elif choice == 2:
            self.algorithm_type1 = 'Epsilon Diagnosis'
        else:
            print("Invalid choice. Please select 1 or 2.")
            self.select_one_phase_algorithm()
    
    def select_two_phase_algorithm(self):
        """
        Allows the user to select the algorithms for Two-Phase RCA.
        """
        print("Select Algorithm for Graph Generation in Two-Phase Model:")
        print("1. Domain Knowledge Graph")
        print("2. GES (Greedy Equivalence Search)")
        print("3. PC (Peter and Clark Algorithm)")
        choice1 = int(input("Enter your choice (1, 2, or 3): "))
        if choice1 == 1:
            self.algorithm_type1 = 'Domain Knowledge Graph'
        elif choice1 == 2:
            self.algorithm_type1 = 'GES'
        elif choice1 == 3:
            self.algorithm_type1 = 'PC'
        else:
            print("Invalid choice. Please select 1, 2, or 3.")
            self.select_two_phase_algorithm()

        print("Select Algorithm for Finding Root Causes in Two-Phase Model:")
        print("1. Random Walk")
        print("2. Hypothesis Testing")
        print("3. Bayesian Network")
        choice2 = int(input("Enter your choice (1, 2, or 3): "))
        if choice2 == 1:
            self.algorithm_type2 = 'Random Walk'
        elif choice2 == 2:
            self.algorithm_type2 = 'Hypothesis Testing'
        elif choice2 == 3:
            self.algorithm_type2 = 'Bayesian Network'
        else:
            print("Invalid choice. Please select 1, 2, or 3.")
            self.select_two_phase_algorithm()
    
    def run_rca(self):
        """
        Runs the RCA based on the selected model and algorithms.
        """
        print("Running RCA with the following parameters:")
        print(f"Model Type: {self.model_type}")
        if self.model_type == 'One-Phase':
            print(f"Algorithm Type: {self.algorithm_type1}")
            if self.algorithm_type1 == 'RCD':
                print("RCD algorithm is currently not implemented due to errors.")
                
            if self.algorithm_type1 == 'Epsilon Diagnosis':
                print("Implementing Epsilon Diagnosis algorithm for one-phase RCA.")
                print("Select Statistical Test Type:")
                print("1. ks")
                print("2. levene")
                print("3. ttest_ind_from_stats")
                print("4. ks_2samp")
                print("5. ranksums")
                print("6. combine_all")
                choice = int(input("Enter your choice (1, 2, 3, 4, 5, or 6): "))
                if choice == 1:
                    self.epsilon_diagnosis_type = 'ks'
                elif choice == 2:
                    self.epsilon_diagnosis_type = 'levene'
                elif choice == 3:
                    self.epsilon_diagnosis_type = 'ttest_ind_from_stats'
                elif choice == 4:
                    self.epsilon_diagnosis_type = 'ks_2samp'
                elif choice == 5:
                    self.epsilon_diagnosis_type = 'ranksums'
                elif choice == 6:
                    self.epsilon_diagnosis_type = 'combine_all'
                else:
                    print("Invalid choice. Please select 1, 2, 3, 4, 5, or 6.")
                
                df, normal_df, abnormal_df, abs_dev_percentages = add_anomaly_column(self.dataset)
                self.predicted_dict = epsilon_diagnosis_function(df=df, test=self.epsilon_diagnosis_type, k=self.num_root_causes, dev=abs_dev_percentages, actual_result_dict=self.actual_dict)
                calculate_accuracy(self.predicted_dict, self.actual_dict)

        elif self.model_type == 'Two-Phase':
            print(f"Algorithm Type for Graph Generation: {self.algorithm_type1}")
            print(f"Algorithm Type for Finding Root Causes: {self.algorithm_type2}")
            graph_df = None
            df, normal_df, abnormal_df, abs_dev_percentages = add_anomaly_column(self.dataset)
            if self.algorithm_type1 == 'Domain Knowledge Graph':
                print("Generating causal graph using domain knowledge graph.")
                graph_df = domain_knowledge_graph(background_file=self.background_knowledge, variable_names=df.columns[1:])

            elif self.algorithm_type1 == 'GES':
                print("Generating causal graph using GES algorithm.")
                graph_df = ges_causal_graph(normal_df=normal_df, background_file=self.background_knowledge)

            elif self.algorithm_type1 == 'PC':
                print("Generating causal graph using PC algorithm.")
                graph_df = pc_causal_graph(normal_df=normal_df, background_file=self.background_knowledge)
            
            if self.algorithm_type2 == 'Random Walk':
                print("Implementing random walk algorithm for two-phase RCA.")
                self.predicted_dict = random_walk_func(graph_df=graph_df, normal_df=normal_df, abnormal_df=abnormal_df, root_cause_top_k=self.num_root_causes, actual_result_dict=self.actual_dict)
                calculate_accuracy(self.predicted_dict, self.actual_dict)

            elif self.algorithm_type2 == 'Hypothesis Testing':
                print("Implementing hypothesis testing algorithm for two-phase RCA.")
                self.predicted_dict = ht_rca_func(graph_df=graph_df, normal_df=normal_df, abnormal_df=abnormal_df, root_cause_top_k=self.num_root_causes, actual_result_dict=self.actual_dict)
                calculate_accuracy(self.predicted_dict, self.actual_dict)

            elif self.algorithm_type2 == 'Bayesian Network':
                print("Bayesian Network based RCA is not currently implemented due to errors.")

    
if __name__ == "__main__":
    dataset = 'datasets/final_dataset.csv'
    background_knowledge = 'datasets/background_knowledge.csv'
    actual_result_dict, max_len = process_csv('datasets/final_anomaly_names.csv')
    k = 4 * max_len
    rca = RCAFramework(dataset, k, background_knowledge, actual_result_dict)
    rca.select_model()
    rca.run_rca()
