import warnings
import numpy as np
import pandas as pd
import networkx as nx

warnings.filterwarnings('ignore')

def process_adjacency_matrix(adjacency_matrix, forbidden_edges, required_edges):
    """
    Processes the adjacency matrix by setting forbidden and required edges.

    The adjacency matrix is used to represent the directed edges in a causal graph.
    - adjacency_matrix[i, j] = 1 indicates a directed edge from node i to node j.
    - adjacency_matrix[i, j] = 0 indicates no edge between node i and node j.

    Parameters:
    - adjacency_matrix (np.ndarray): Initial adjacency matrix.
    - forbidden_edges (list of tuple): List of edges that are forbidden. Each tuple (i, j) indicates an edge from node i to node j is forbidden.
    - required_edges (list of tuple): List of edges that are required. Each tuple (i, j) indicates an edge from node i to node j is required.

    Returns:
    - np.ndarray: Processed adjacency matrix with the forbidden and required edges applied.
    """
    for (i, j) in forbidden_edges:
        adjacency_matrix[i, j] = 0
    for (i, j) in required_edges:
        adjacency_matrix[j, i] = 0
        adjacency_matrix[i, j] = 1
    return adjacency_matrix

def parse_background_knowledge(file_path, variable_names):
    """
    Parses the background knowledge file to extract the forbidden and required edges.

    Parameters:
    - file_path (str): Path to the background knowledge file.
    - variable_names (list): List of variable names representing the node names.

    Returns:
    - tuple: Lists of forbidden and required edges.
    """
    forbidden_edges = []
    required_edges = []
    variable_names = list(variable_names)
    with open(file_path, 'r') as file:
        for line in file:
            parts = line.strip().split(',')
            if parts[0].strip() == 'forbidden':
                forbidden_edges.append((variable_names.index(parts[1].strip()), variable_names.index(parts[2].strip())))
            elif parts[0].strip() == 'required':
                required_edges.append((variable_names.index(parts[1].strip()), variable_names.index(parts[2].strip())))
    return forbidden_edges, required_edges

def save_graph_as_png(adjacency_matrix, column_names, output_path='causal_graph.png'):
    """
    Saves the adjacency matrix as a PNG image of the causal graph.

    This function converts the given adjacency matrix into a directed graph and saves it as an image file. 
    The nodes of the graph represent the column names, and the directed edges represent the causal relationships 
    between the nodes(metrics) indicated by the adjacency matrix.

    Parameters:
    - adjacency_matrix (np.ndarray): Adjacency matrix where adjacency_matrix[i, j] = 1 indicates a directed edge from node i to node j.
    - column_names (list): List of column names representing the nodes in the graph.
    - output_path (str): Path to save the PNG image. 
    """
    G = nx.DiGraph()

    for var in column_names:
        G.add_node(var)

    for i, var1 in enumerate(column_names):
        for j, var2 in enumerate(column_names):
            if adjacency_matrix[i, j] == 1:
                G.add_edge(var1, var2)

    A = nx.nx_agraph.to_agraph(G)
    A.layout(prog='dot')
    A.draw(output_path)

def domain_knowledge_graph(background_file, variable_names):
    """
    Generates a causal graph using domain knowledge and saves it as a PNG image.
    
    The causal graph is used for further root cause analysis. If there is a directed edge from node i to node j, 
    it implies that node i has a cause and effect relationship with node j. The adjacency matrix is processed 
    based on the forbidden and required edges specified in the background knowledge file.

    Parameters:
    - background_file (str): Path to the background knowledge file.
    - variable_names (list): List of variable names in the dataset.

    Returns:
    - pd.DataFrame: DataFrame representing the adjacency matrix of the causal graph.
    """
    variable_names = variable_names[:-1]
    n = len(variable_names)
    output_file = 'domain_knowledge_graph.png'
    forbidden_edges, required_edges = parse_background_knowledge(background_file, variable_names)
    adjacency_matrix = np.zeros((n, n))
    processed_matrix = process_adjacency_matrix(adjacency_matrix, forbidden_edges, required_edges)
    save_graph_as_png(processed_matrix, variable_names, output_path=output_file)
    graph_df = pd.DataFrame(processed_matrix, index=variable_names, columns=variable_names)
    return graph_df
