import warnings
import pandas as pd
import networkx as nx
from causallearn.search.ConstraintBased.PC import pc

warnings.filterwarnings('ignore')

def process_adjacency_matrix(adjacency_matrix, forbidden_edges, required_edges):
    """
    Processes the adjacency matrix by setting forbidden and required edges.

    The adjacency matrix is used to represent the directed edges in a causal graph.
    - adjacency_matrix[i, j] = 1 indicates a directed edge from node i to node j.
    - adjacency_matrix[i, j] = 0 indicates no edge between node i and node j.

    Parameters:
    - adjacency_matrix (np.ndarray): Initial adjacency matrix.
    - forbidden_edges (list of tuple): List of edges that are forbidden. Each tuple (i, j) indicates an edge from node i to node j is forbidden.
    - required_edges (list of tuple): List of edges that are required. Each tuple (i, j) indicates an edge from node i to node j is required.

    Returns:
    - np.ndarray: Processed adjacency matrix with the forbidden and required edges applied.
    """
    n = adjacency_matrix.shape[0]
    for i in range(n - 1):
        for j in range(i + 1, n):
            if adjacency_matrix[i, j] == -1 and adjacency_matrix[j, i] == -1:
                adjacency_matrix[j, i] = 0
                adjacency_matrix[i, j] = 0
            elif adjacency_matrix[i, j] == -1 and adjacency_matrix[j, i] == 0:
                adjacency_matrix[j, i] = 1
            elif adjacency_matrix[i, j] == 0 and adjacency_matrix[j, i] == -1:
                adjacency_matrix[i, j] = 1
    adjacency_matrix[adjacency_matrix == -1] = 0

    for (i, j) in forbidden_edges:
        adjacency_matrix[i, j] = 0
    for (i, j) in required_edges:
        adjacency_matrix[i, j] = 1
        adjacency_matrix[j, i] = 0

    return adjacency_matrix

def run_pc_algorithm(data, alpha=0.05, indep_test='fisherz', stable=True, uc_rule=0, uc_priority=2, mvpc=False, correction_name='MV_Crtn_Fisher_Z', verbose=False, show_progress=True):
    """
    Runs the PC algorithm to learn the causal graph structure from the normal data.

    Parameters:
    - data (pd.DataFrame): Input dataframe with variables(metrics) as columns.
    - alpha (float): Significance level for conditional independence tests. Default is 0.05.
    - indep_test (str): Independence test method. Default is 'fisherz'.
    - stable (bool): Use stabilized skeleton discovery if True. Default: True
    - uc_rule (int): Orientation rule for unshielded colliders. Default is 0.
    - uc_priority (int): Resolution rule for collider conflicts. Default is 2.
    - mvpc (bool): Use missing-value PC. Default: False.
    - correction_name (str): Method for missing-value correction (if mvpc=True). Default: 'MV_Crtn_Fisher_Z'.
    - verbose (bool): Print verbose output if True. Default: False.
    - show_progress (bool): Whether to show progress during the algorithm run. Default is True.

    Returns:
    - nx.DiGraph: Directed graph representing the causal relationships between the metrics.
    """
    data_values = data.values
    cg = pc(data_values, alpha=alpha, indep_test=indep_test, stable=stable, uc_rule=uc_rule, uc_priority=uc_priority, mvpc=mvpc, correction_name=correction_name, verbose=verbose, show_progress=show_progress)
    return cg

def visualize_processed_graph(processed_matrix, variable_names, output_file='pc_causal_graph.png'):
    """
    Visualizes the processed adjacency matrix and then builds a causal graph and saves it as a PNG image.

    The adjacency matrix represents the directed edges in a causal graph.
    - adjacency_matrix[i, j] = 1 indicates a directed edge from node i to node j.
    - adjacency_matrix[i, j] = 0 indicates no edge between node i and node j.

    Parameters:
    - processed_matrix (np.ndarray): Processed adjacency matrix.
    - variable_names (list): List of variable names (node names) for the graph nodes.
    - output_file (str): Path to save the PNG image of the causal graph.
    """
    G = nx.DiGraph()

    for var in variable_names:
        G.add_node(var)

    for i, var1 in enumerate(variable_names):
        for j, var2 in enumerate(variable_names):
            if processed_matrix[i, j] == 1:
                G.add_edge(var1, var2)

    A = nx.nx_agraph.to_agraph(G)
    A.layout(prog='dot')

    A.draw(output_file)

def parse_background_knowledge(background_file, variable_names):
    """
    Parses the background knowledge file to extract the forbidden and required edges.

    Parameters:
    - file_path (str): Path to the background knowledge file.
    - variable_names (list): List of variable names representing the node names.

    Returns:
    - tuple: Lists of forbidden and required edges.
    """
    forbidden_edges = []
    required_edges = []
    with open(background_file, 'r') as file:
        lines = file.readlines()
        for line in lines:
            parts = line.strip().split(',')
            if parts[0].strip() == 'forbidden':
                forbidden_edges.append((variable_names.index(parts[1].strip()), variable_names.index(parts[2].strip())))
            elif parts[0].strip() == 'required':
                required_edges.append((variable_names.index(parts[1].strip()), variable_names.index(parts[2].strip())))
    return forbidden_edges, required_edges

def pc_causal_graph(normal_df, background_file):
    """
    Generates a causal graph using the PC algorithm based on the normal data along with background domain knowledge.
    
    The causal graph is used for further root cause analysis. If there is a directed edge from node i to node j, 
    it implies that node i has a cause and effect relationship with node j. The adjacency matrix is processed 
    based on the forbidden and required edges specified in the background knowledge file.

    Parameters:
    - normal_df (pd.DataFrame): Dataframe containing the variables for which causal relationships are to be inferred.
    - background_file (str): Path to the background knowledge file containing prior constraints on causal relationships.

    Returns:
    - pd.DataFrame: DataFrame representation of the adjacency matrix of the causal graph.
    """
    del_columns = [normal_df.columns[0], 'anomaly']
    normal_df = normal_df.drop(columns=del_columns)
    variable_names = list(normal_df.columns)
    indep_test = 'chisq'
    
    forbidden_edges, required_edges = parse_background_knowledge(background_file, variable_names)
    
    cg = run_pc_algorithm(data=normal_df, indep_test=indep_test)
    processed_matrix = process_adjacency_matrix(cg.G.graph, forbidden_edges, required_edges)
    
    output_file = 'pc_causal_graph.png'
    visualize_processed_graph(processed_matrix=processed_matrix, variable_names=variable_names, output_file=output_file)
    graph_df = pd.DataFrame(processed_matrix, index=variable_names, columns=variable_names)
    
    return graph_df
