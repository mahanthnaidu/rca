import warnings
import numpy as np
from scipy.stats import (
    ttest_ind_from_stats, kstest, ks_2samp, 
    ranksums, combine_pvalues, levene, 
)

warnings.filterwarnings('ignore')

def epsilon_diagnosis(normal_df, abnormal_df, test='ks'):
    """
    Performs two sample statistical hypothesis tests to assess the
    statistical significance between normal and abnormal data.

    Parameters:
    - normal_df (pd.DataFrame): DataFrame containing normal data.
    - abnormal_df (pd.DataFrame): DataFrame containing abnormal data.
    - test (str): Type of statistical test to use ('ks', 'levene', 'ttest_ind_from_stats', 'ks_2samp', 'ranksums', 'combine_all').

    Returns:
    - dict: Dictionary with metrics as keys and p-values as values.
    """
    root_causes = {}
    metrics = normal_df.columns
    
    for metric in metrics:
        normal_values = normal_df[metric].values
        abnormal_values = abnormal_df[metric].values
        
        if test == 'ks':
            statistic, p_value = kstest(normal_values, abnormal_values)
        elif test == 'levene':
            statistic, p_value = levene(normal_values, abnormal_values)
        elif test == 'ttest_ind_from_stats':
            mean1, std1, nobs1 = np.mean(normal_values), np.std(normal_values), len(normal_values)
            mean2, std2, nobs2 = np.mean(abnormal_values), np.std(abnormal_values), len(abnormal_values)
            statistic, p_value = ttest_ind_from_stats(mean1, std1, nobs1, mean2, std2, nobs2)
        elif test == 'ks_2samp':
            statistic, p_value = ks_2samp(normal_values, abnormal_values)
        elif test == 'ranksums':
            statistic, p_value = ranksums(normal_values, abnormal_values)
        elif test == 'combine_all':
            mean1, std1, nobs1 = np.mean(normal_values), np.std(normal_values), len(normal_values)
            mean2, std2, nobs2 = np.mean(abnormal_values), np.std(abnormal_values), len(abnormal_values)
            _, p_values = zip(
                *[kstest(normal_values, abnormal_values),
                  ttest_ind_from_stats(mean1, std1, nobs1, mean2, std2, nobs2),
                  levene(normal_values, abnormal_values)]
            )
            statistic, p_value = combine_pvalues(p_values)
        else:
            raise ValueError(f"Unknown test: {test}")
        
        root_causes[metric] = p_value
    
    return root_causes

def compute_significance_scores(p_values):
    """
    Compute significance scores from p-values.

    Parameters:
    - p_values (list): List of p-values.

    Returns:
    - np.array: Array of significance scores.
    """
    p_values = np.array(p_values)
    p_values[p_values == 0] = np.finfo(float).eps
    # significance_scores = 1 / p_values
    significance_scores = -np.log10(p_values)
    return significance_scores

def normalize_scores(scores):
    """
    Normalizes the scores to sum up to 1.

    Parameters:
    - scores (np.array): Array of scores.

    Returns:
    - np.array: Normalized scores.
    """
    total = np.sum(scores)
    if total == 0:
        return np.zeros_like(scores)
    normalized_scores = scores / total
    return normalized_scores

def allocate_changes(overall_change, weights):
    """
    Allocate the changes based on their weights.

    Parameters:
    - overall_change (float): Overall change in the anomaly value.
    - weights (np.array): Array of weights.

    Returns:
    - np.array: Changes allocated based on the weights.
    """
    changes = overall_change * weights
    return changes

def quantify_root_causes(root_causes, overall_change):
    """
    Quantify root causes based on statistical significance and overall change.

    Parameters:
    - root_causes (list): List of tuples (metric, p_value) representing root causes.
    - overall_change (float): Overall change value.

    Returns:
    - dict: Dictionary of quantified root causes with metrics as keys and (change, weight) as values.
    """
    root_causes_dict = {metric: p_value for metric, p_value in root_causes}
    
    p_values = list(root_causes_dict.values())
    significance_scores = compute_significance_scores(p_values)
    weights = normalize_scores(significance_scores)
    changes = allocate_changes(overall_change, weights)
    
    quantified_root_causes = {}
    for i, (metric, _) in enumerate(root_causes):
        change = changes[i]
        quantified_root_causes[metric] = (change, weights[i] * 100)
    
    return quantified_root_causes

def epsilon_diagnosis_function(df, test='ks', k=10, dev=[], actual_result_dict={}):
    """
    Perform epsilon diagnosis RCA (Root Cause Analysis) on the input DataFrame.

    Parameters:
    - df (pd.DataFrame): Input DataFrame containing anomaly and metric data.
    - test (str): Type of statistical test to use ('ks', 'levene', 'ttest_ind_from_stats', 'ks_2samp', 'ranksums', 'combine_all').
    - k (int): Number of top root causes to consider.
    - dev (list): List of deviations or overall changes for each row.
    - actual_result_dict (dict): Dictionary of actual results.

    Returns:
    - dict: Dictionary of RCA results with date-hour entries and corresponding root causes.
    """
    normal_df = df[df['anomaly'] == 0].drop(columns=['anomaly', 'dt_hr'])
    abnormal_df = df[df['anomaly'] == 1]
    dt_hr_df = abnormal_df[['dt_hr']]
    abnormal_df = abnormal_df.drop(columns=['anomaly', 'dt_hr'])
    normal_df = normal_df.drop(columns=[normal_df.columns[0]])
    abnormal_df = abnormal_df.drop(columns=[abnormal_df.columns[0]])
    
    results = {}
    for i in range(len(abnormal_df)):
        current_abnormal_row = abnormal_df.iloc[[i]]
        root_causes = epsilon_diagnosis(normal_df, current_abnormal_row, test=test)
        
        sorted_root_causes = sorted(root_causes.items(), key=lambda item: item[1])
        overall_change = dev[i]  
        quantified_root_causes = quantify_root_causes(sorted_root_causes[:10], overall_change)
        
        dt_hr = dt_hr_df['dt_hr'].iloc[i]
        print(f"Date-Hour: {dt_hr_df['dt_hr'].iloc[i]}, Epsilon Diagnosis RCA Top 10 Root Causes for row {i} are:")
        for metric, (change, percent) in quantified_root_causes.items():
            print(f"  Root Cause: {metric}, Root Cause Value: {change} ")

        results[dt_hr] = set()

        for key, _ in sorted_root_causes:
            if key.endswith('_transaction%'):
                key = key[:-13]
            elif key.endswith('_success%'):
                key = key[:-9]

            results[dt_hr].add(key)
            if(len(results[dt_hr]) == 2*len(actual_result_dict[dt_hr])):
                break 
    print("RCA process completed.")
    return results
