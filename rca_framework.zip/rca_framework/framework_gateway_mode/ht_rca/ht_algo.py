import warnings
import pandas as pd
from pyrca.analyzers.ht import HT, HTConfig

warnings.filterwarnings('ignore')

def run_ht_rca(graph_df, normal_df, anomalous_metrics, abnormal_df, root_cause_top_k, dt_hr_df, actual_result_dict):
    """
    Performs the Hypothesis Testing Root Cause Analysis (HT-RCA) using a given configuration to find root causes of anomalous metrics.

    Args:
    - graph_df (pd.DataFrame): Dataframe representing the graph structure or dependencies.
    - normal_df (pd.DataFrame): Dataframe containing normal data for training the HT RCA model.
    - anomalous_metrics (str): Name of the anomalous metric column in the abnormal dataframe.
    - abnormal_df (pd.DataFrame): Dataframe containing abnormal or anomalous data for analysis.
    - root_cause_top_k (int): Number of top root causes to identify per abnormal row.
    - dt_hr_df (pd.DataFrame): Dataframe containing datetime-hour information for abnormal rows.
    - actual_result_dict (dict): Dictionary mapping datetime-hour to actual results or expected outcomes.

    Returns:
    - root_causes_dict (dict): Dictionary mapping date-hour to sets of identified root causes.
    """
    config = HTConfig(graph=graph_df, aggregator='sum', root_cause_top_k=root_cause_top_k)
    ht_rca = HT(config=config)
    ht_rca.train(normal_df)
    
    root_causes_dict = {}
    for index, row in abnormal_df.iterrows():
        single_row_df = pd.DataFrame([row])
        root_causes = ht_rca.find_root_causes(
            abnormal_df=single_row_df, 
            anomalous_metrics=anomalous_metrics, 
            adjustment=True
        )
        print(f"Date-Hour: {dt_hr_df['dt_hr'].iloc[index]}, HT RCA Top 10 Root Causes for row {index} are:")
        for node in root_causes.root_cause_nodes[:10]:
            if node[0] != anomalous_metrics: 
                print('  Root Cause: ' + node[0] + ', Root Cause Value: ' + str(node[1]))

        dt_hr = dt_hr_df['dt_hr'].iloc[index]
        root_causes_set = set()
        for node in root_causes.root_cause_nodes:
            value = node[0]
            if value != anomalous_metrics:
                if value.endswith('_transaction%'):
                    value = value[:-13]
                elif value.endswith('_success%'):
                    value = value[:-9]
                root_causes_set.add(value)
            if(len(root_causes_set) == 2*len(actual_result_dict[dt_hr])):
                break
        root_causes_dict[dt_hr] = root_causes_set
    
    return root_causes_dict


def ht_rca_func(graph_df, normal_df, abnormal_df, root_cause_top_k, actual_result_dict):
    """
    Wrapper function to perform HT RCA analysis on the input data.

    Args:
    - graph_df (pd.DataFrame): Dataframe representing the graph structure or dependencies.
    - normal_df (pd.DataFrame): Dataframe containing normal data for training the HT RCA model.
    - abnormal_df (pd.DataFrame): Dataframe containing abnormal or anomalous data for analysis.
    - root_cause_top_k (int): Number of top root causes to identify per abnormal row.
    - actual_result_dict (dict): Dictionary mapping datetime-hour to actual results or expected outcomes.

    Returns:
    - root_causes_dict (dict): Dictionary mapping date-hour to sets of identified root causes.
    """
    del_columns = [abnormal_df.columns[0], 'anomaly']
    dt_hr_df = abnormal_df[['dt_hr']]
    abnormal_df = abnormal_df.drop(columns=del_columns)
    normal_df = normal_df.drop(columns=del_columns)
    anomalous_metrics = abnormal_df.columns[0]
    
    root_causes_dict = run_ht_rca(
        graph_df=graph_df,
        normal_df=normal_df,
        anomalous_metrics=anomalous_metrics,
        abnormal_df=abnormal_df,
        root_cause_top_k=root_cause_top_k,
        dt_hr_df=dt_hr_df, 
        actual_result_dict = actual_result_dict
    )
    print("RCA process completed.")
    return root_causes_dict
