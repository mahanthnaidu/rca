import warnings
import pandas as pd
from pyrca.analyzers.ht import HT, HTConfig

warnings.filterwarnings('ignore')

def run_ht_rca(graph_df, normal_df, anomalous_metrics, abnormal_df, root_cause_top_k, dt_hr_df, result_dict):
    config = HTConfig(graph=graph_df, aggregator='sum', root_cause_top_k=root_cause_top_k)
    ht_rca = HT(config=config)
    ht_rca.train(normal_df)
    
    root_causes_dict = {}
    for index, row in abnormal_df.iterrows():
        single_row_df = pd.DataFrame([row])
        root_causes = ht_rca.find_root_causes(
            abnormal_df=single_row_df, 
            anomalous_metrics=anomalous_metrics, 
            adjustment=True
        )
        print(f"Date-Hour: {dt_hr_df['dt_hr'].iloc[index]}, HT RCA Top 10 Root Causes for row {index} are:")
        for node in root_causes.root_cause_nodes[:10]:
            if node[0] != anomalous_metrics: 
                print('  Root Cause: ' + node[0] + ', Root Cause Value: ' + str(node[1]))

        dt_hr = dt_hr_df['dt_hr'].iloc[index]
        root_causes_set = set()
        for node in root_causes.root_cause_nodes:
            value = node[0]
            if value != anomalous_metrics:
                if value.endswith('_transaction%'):
                    value = value[:-13]
                elif value.endswith('_success%'):
                    value = value[:-9]
                root_causes_set.add(value)
            if(len(root_causes_set) == 2*len(result_dict[dt_hr])):
                # print("***************************************")
                # print(len(root_causes_set))
                # print(len(result_dict[dt_hr]))
                # print("***************************************")
                break
        root_causes_dict[dt_hr] = root_causes_set
    
    return root_causes_dict


def ht_rca_func(graph_df, normal_df, abnormal_df, root_cause_top_k, result_dict):
    del_columns = [abnormal_df.columns[0], 'anomaly']
    dt_hr_df = abnormal_df[['dt_hr']]
    abnormal_df = abnormal_df.drop(columns=del_columns)
    normal_df = normal_df.drop(columns=del_columns)
    anomalous_metrics = abnormal_df.columns[0]
    
    root_causes_dict = run_ht_rca(
        graph_df=graph_df,
        normal_df=normal_df,
        anomalous_metrics=anomalous_metrics,
        abnormal_df=abnormal_df,
        root_cause_top_k=root_cause_top_k,
        dt_hr_df=dt_hr_df, 
        result_dict = result_dict
    )
    
    return root_causes_dict
