import warnings
import numpy as np
import pandas as pd
from typing import List
from pyrca.analyzers.base import RCAResults
from pyrca.analyzers.random_walk import RandomWalkConfig, RandomWalk

warnings.filterwarnings('ignore')

class CustomRandomWalk(RandomWalk):
    def __init__(self, config: RandomWalkConfig, random_seed=None):
        super().__init__(config)
        self.random_seed = random_seed
    
    def _random_walk(self, graph, start, num_steps, num_repeats, random_seed=None):
        if random_seed is not None:
            np.random.seed(random_seed)
        elif self.random_seed is not None:
            np.random.seed(self.random_seed)
        
        scores = {}
        for _ in range(num_repeats):
            node = start
            for _ in range(num_steps):
                probs = graph[node]["probs"]
                probs = np.nan_to_num(probs)
                probs = probs / sum(probs)
                index = np.random.choice(list(range(len(probs))), p=probs)
                node = graph[node]["nodes"][index]
                scores[node] = scores.get(node, 0) + 1
        
        for node in scores:
            scores[node] /= num_repeats * num_steps
        
        return scores
    
    def _build_weighted_graph(self, df, anomalies, rho):
        metrics = df.columns
        node_weights = self._node_weight(df, anomalies)
        self_weights = self._self_weight(df, anomalies, node_weights)
        node_ws = {metric: max(values) for metric, values in node_weights.items()}
        self_ws = {metric: max(values) for metric, values in self_weights.items()}
        graph = {m: {"nodes": [], "weights": [], "probs": None} for m in metrics}

        for metric in metrics:
            for p in self.graph.predecessors(metric):
                graph[metric]["nodes"].append(p)
                graph[metric]["weights"].append(node_ws[p])
            for p in self.graph.successors(metric):
                graph[metric]["nodes"].append(p)
                graph[metric]["weights"].append(node_ws[p] * rho)
            graph[metric]["nodes"].append(metric)
            graph[metric]["weights"].append(self_ws[metric])

        for metric in graph.keys():
            w = np.array(graph[metric]["weights"])
            w = np.where(w == 0, 1e-10, w)
            graph[metric]["probs"] = w / sum(w)
        
        return graph

    def find_root_causes(self, anomalous_metrics: List[str], df: pd.DataFrame, random_seed=None, **kwargs) -> RCAResults:
        levels = self._get_node_levels(self.adjacency_mat)
        graph = self._build_weighted_graph(df, anomalous_metrics, self.config.rho)
        counts = {
            anomaly: self._random_walk(
                graph,
                anomaly,
                self.config.num_steps,
                self.config.num_repeats,
                random_seed=random_seed if random_seed is not None else self.random_seed,
            )
            for anomaly in anomalous_metrics
        }
    
        merged_counts = {}
        for anomaly in anomalous_metrics:
            for key, value in counts[anomaly].items():
                merged_counts[key] = merged_counts.get(key, 0) + value

        for metric in df.columns:
            if metric not in merged_counts:
                merged_counts[metric] = 0
    
        node_scores = {m: v / sum(merged_counts.values()) for m, v in merged_counts.items()}

        # Filter out anomalous metrics from root cause nodes
        root_cause_nodes = [(m, score) for m, score in sorted(node_scores.items(), key=lambda x: x[1], reverse=True)
                        if m not in anomalous_metrics][:self.config.root_cause_top_k]
    
        root_cause_paths = {}
        for root, _ in root_cause_nodes:
            paths = []
            for anomaly in anomalous_metrics:
                path_scores = self._get_root_cause_paths(root, anomaly, node_scores)
                for nodes, path_score in path_scores:
                    paths.append((path_score, [(node, None) for node in nodes]))
            root_cause_paths[root] = paths

        return RCAResults(root_cause_nodes=root_cause_nodes, root_cause_paths=root_cause_paths)
    

def run_random_walk_rca(graph_df, normal_df, anomalous_metrics, abnormal_df, root_cause_top_k, dt_hr_df, random_seed=None, result_dict=[]):
    config = RandomWalkConfig(graph=graph_df, root_cause_top_k=root_cause_top_k)
    rw_rca = CustomRandomWalk(config, random_seed=random_seed)
    
    root_causes_dict = {}
    for index, row in abnormal_df.iterrows():
        single_row_df = pd.DataFrame([row])
        root_causes = rw_rca.find_root_causes(anomalous_metrics=anomalous_metrics, df=normal_df, random_seed=random_seed)
        print(f"Date-Hour: {dt_hr_df['dt_hr'].iloc[index]}, Random Walk RCA Top 10 Root Causes for row {index} are:")
        for node in root_causes.root_cause_nodes[:10]:
            print('  Root Cause: ' + node[0] + ', Root Cause Value: ' + str(node[1]))
        dt_hr = dt_hr_df['dt_hr'].iloc[index]
        root_causes_set = set()
        for node in root_causes.root_cause_nodes:
            value = node[0]
            if value != anomalous_metrics:
                if value.endswith('_transaction%'):
                    value = value[:-13]
                elif value.endswith('_success%'):
                    value = value[:-9]
                root_causes_set.add(value)
            if(len(root_causes_set) == 2*len(result_dict[dt_hr])):
                # print("***************************************")
                # print(len(root_causes_set))
                # print(len(result_dict[dt_hr]))
                # print("***************************************")
                break
        root_causes_dict[dt_hr] = root_causes_set
    
    return root_causes_dict


def random_walk_func(graph_df, normal_df, abnormal_df, root_cause_top_k, random_seed=None, result_dict=[]):
    del_columns = [abnormal_df.columns[0], 'anomaly']
    dt_hr_df = abnormal_df[['dt_hr']]
    abnormal_df = abnormal_df.drop(columns=del_columns)
    normal_df = normal_df.drop(columns=del_columns)
    anomalous_metrics = [abnormal_df.columns[0]]
    
    root_causes_dict = run_random_walk_rca(
        graph_df=graph_df,
        normal_df=normal_df,
        anomalous_metrics=anomalous_metrics,
        abnormal_df=abnormal_df,
        root_cause_top_k=root_cause_top_k,
        dt_hr_df=dt_hr_df,
        random_seed=random_seed,
        result_dict=result_dict 
    )
    
    return root_causes_dict
